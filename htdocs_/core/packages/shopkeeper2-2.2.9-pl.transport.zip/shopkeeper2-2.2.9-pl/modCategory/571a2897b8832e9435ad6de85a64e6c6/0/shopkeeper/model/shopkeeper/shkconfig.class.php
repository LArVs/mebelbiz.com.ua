<?php
class SHKconfig extends xPDOSimpleObject {}