<?php
require_once (dirname(dirname(__FILE__)) . '/shkorder.class.php');
class SHKorder_mysql extends SHKorder {}