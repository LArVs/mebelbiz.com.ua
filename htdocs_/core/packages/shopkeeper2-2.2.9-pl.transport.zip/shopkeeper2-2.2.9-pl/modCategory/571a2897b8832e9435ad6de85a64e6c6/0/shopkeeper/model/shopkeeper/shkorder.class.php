<?php
class SHKorder extends xPDOSimpleObject {}