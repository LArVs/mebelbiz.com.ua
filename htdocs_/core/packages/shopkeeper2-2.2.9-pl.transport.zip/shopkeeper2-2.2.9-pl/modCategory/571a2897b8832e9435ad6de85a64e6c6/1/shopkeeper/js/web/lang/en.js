
var langTxt = new Array();

langTxt['delAll'] = "Empty cart";
langTxt['select'] = "You have chosen:";
langTxt['empty'] = "Empty";
langTxt['confirm'] = "Are you sure?";
langTxt['continue'] = "OK";
langTxt['yes'] = "Yes";
langTxt['cancel'] = "Cancel";
langTxt['cookieError'] = "Cookies should be enabled in the browser.";
langTxt['delete'] = "Delete";
langTxt['delGoods'] = "Remove items";
langTxt['goods'] = "items";
langTxt['count'] = "Quantity";
langTxt['sumTotal'] = "Total :";
langTxt['executeOrder'] = "Submit order";
langTxt['changeCount'] = "Change quantity";
langTxt['addedToCart'] = "Product added<br /> to cart";

langTxt['error_jqVersion'] = "Shopkeeper is required to work jQuery version 1.7+. You are using: ";
