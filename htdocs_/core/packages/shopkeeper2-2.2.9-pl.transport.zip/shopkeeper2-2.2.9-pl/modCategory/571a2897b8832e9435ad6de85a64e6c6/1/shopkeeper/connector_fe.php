<?php
/**
 * Shopkeeper frontend connector
 *
 * @package shopkeeper
 */

require dirname(dirname(dirname(dirname(__FILE__))))."/config.core.php";
require MODX_CORE_PATH."components/shopkeeper/ajax-action.php";

?>