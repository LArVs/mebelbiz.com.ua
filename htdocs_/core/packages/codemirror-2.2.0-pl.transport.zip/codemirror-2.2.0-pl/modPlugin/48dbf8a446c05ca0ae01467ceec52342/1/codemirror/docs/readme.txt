--------------------
Extra: CodeMirror
--------------------
Version: 1.0.0
Created: June 23rd, 2010
Author: Shaun McCormick <shaun+codemirror@modx.com>
License: GNU GPLv2 (or later at your option)

Integrates CodeMirror RTE into MODx Revolution.

Please see the documentation at:
http://rtfm.modx.com/display/ADDON/CodeMirror/

Thanks for using CodeMirror!
Shaun McCormick
shaun+codemirror@modx.com