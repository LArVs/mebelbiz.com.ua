--------------------
Snippet: Batcher
--------------------
Version: 1.0.0
Since: June 4th, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

This is a simple search component. Please see the documentation at:
http://docs.modxcms.com/display/ADDON/Batcher/

Thanks for using Batcher!
Shaun McCormick
shaun@modxcms.com