<p>In the online store made ​​an new order.</p>

<p>Order number: [[+orderID]]</p>

<b>The composition of the order:</b>

[[+orderData]]

<br /><br />

<b>Customer data:</b><br />

<table cellpadding="3">
  <tr><td>Address:</td><td>[[+address]]</td></tr>
  <tr><td>Delivery method:</td><td>[[+shk_delivery]]</td></tr>
  <tr><td>Payment method:</td><td>[[+payment]] </td></tr>
  <tr><td>Name:</td><td>[[+fullname]]</td></tr>
  <tr><td>E-mail:</td><td><a href="mailto:[[+email]]">[[+email]]</a></td></tr>
  <tr><td>Phone:</td><td>[[+phone]]</td></tr>
  <tr><td>Comment:</td><td>[[+message]]</td></tr>
</table>
