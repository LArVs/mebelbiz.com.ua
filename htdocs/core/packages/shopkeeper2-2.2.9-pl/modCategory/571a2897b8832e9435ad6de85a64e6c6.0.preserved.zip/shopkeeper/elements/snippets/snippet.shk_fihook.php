<?php
return require MODX_CORE_PATH.'components/shopkeeper/shk_fihook.inc.php';