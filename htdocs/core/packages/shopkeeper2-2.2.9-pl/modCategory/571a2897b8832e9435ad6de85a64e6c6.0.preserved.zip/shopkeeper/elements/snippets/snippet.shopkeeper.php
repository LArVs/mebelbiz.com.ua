<?php
return require MODX_CORE_PATH.'components/shopkeeper/shopkeeper.inc.php';