
Shopkeeper 2.x for MODx Revolution

http://modx-shopkeeper.ru/

Разработано при поддержке студии "Симпл Дрим" (http://www.simpledream.ru/).

---------------------------------------

Shopping cart and order management.

See /docs/.
