<?php
require_once (dirname(dirname(__FILE__)) . '/shkconfig.class.php');
class SHKconfig_mysql extends SHKconfig {}