<?php
$xpdo_meta_map['SHKconfig']= array (
  'package' => 'shopkeeper',
  'table' => 'shopkeeper_config',
  'fields' => 
  array (
    'setting' => '',
    'value' => '',
    'xtype' => '',
  ),
  'fieldMeta' => 
  array (
    'setting' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '15',
      'phptype' => 'string',
      'null' => false,
      'default' => '',
    ),
    'value' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => false,
      'default' => '',
    ),
    'xtype' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '15',
      'phptype' => 'string',
      'null' => false,
      'default' => '',
    ),
  ),
);
