<?php
/**
 * migx
 *
 * @package migx
 * @language de
 */


$_lang['mig.tabs'] = 'Formular Tabs';
$_lang['mig.columns'] = 'Grid Spalten';
$_lang['mig.btntext'] = '"Datensatz erstellen" Ersetzung';
$_lang['mig.previewurl'] = 'Vorschau Url';
$_lang['mig.jsonvarkey'] = 'Vorschau JsonVarKey';
$_lang['mig.configs'] = 'Konfigurationen';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';