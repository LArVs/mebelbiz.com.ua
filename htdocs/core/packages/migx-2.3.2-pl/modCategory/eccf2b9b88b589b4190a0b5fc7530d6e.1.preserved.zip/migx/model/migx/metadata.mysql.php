<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'migxConfig',
    1 => 'migxConfigElement',
    2 => 'migxElement',
  ),
);